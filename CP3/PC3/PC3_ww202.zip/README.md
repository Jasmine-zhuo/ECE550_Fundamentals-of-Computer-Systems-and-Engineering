Checkpoint 3
Name: Wenzhuo Wu
Netid: ww202
In this checkpoint, 32 32-bit regfiles are built by using D-flip-flop and tri-state buffers. 
Read and write operation can be achieved.
ctrl_writeEnable is the wirte enable signal,
ctrl_readRegA, ctrl_readRegB is the select read input.
ctrl_writeReg is the select write input.
data_writeReg is the data needed to be written.
data_readRegA, data_readRegB are the output.

