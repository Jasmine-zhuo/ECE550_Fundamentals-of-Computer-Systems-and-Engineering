# Checkpoint 1

Name: Haoyu Fu

netID: hf83



Firstly, the main addition function was achieved by a **32 bits carry select adder**, which was further implemented by 16 bits CSA, 8 bits CSA and 4bits RCA. I use **cin** and **cout** to be the input and output of this "**CSA32()**" function. The subtraction was reached by applying 2's complement to **wire B**, which was selected by a multiplexer according to the **least significant bits** of ctrl_ALUopcode (after this processing, the input to ALU is "**B[31:0]**"). Besides, if doing subtraction, the carry in should be set as 1 also according to the **least significant bits** of ctrl_ALUopcode. Finally, this design could pass the testbench simulation **without errors**.  

